package ASE.deliverySpring;

import ASE.deliverySpring.utils.DataUtil;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeliverySpringApplication {

	public static void main(String[] args) {

		SpringApplication.run(DeliverySpringApplication.class, args);


	}

}
