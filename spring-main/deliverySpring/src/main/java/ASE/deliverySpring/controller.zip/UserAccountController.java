package ASE.deliverySpring.controller;

import ASE.deliverySpring.base.BaseController;
import ASE.deliverySpring.base.BaseMessage;
import ASE.deliverySpring.entity.UserAccount;
import ASE.deliverySpring.utils.DataUtil;
import ASE.deliverySpring.utils.Result;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 描述:
 * 用户接口管理
 * @author test
 * @version 1.0
 * 版权所有：
 * @className UserAccountController
 * @projectName deliverySpring
 * @date 2022/12/3
 */

@CrossOrigin
@RestController
@RequestMapping("/v1/api/user")
public class UserAccountController extends BaseController {

    /**
     * 用户列表查询
     * @return
     */
    @GetMapping("/find/all")
    public Result findAll(){

        try{

            List<UserAccount> userAccounts = userAccountService.findAll();

            return Result.success("查询成功",userAccounts);

        }catch (Exception e){
            e.printStackTrace();
        }

        return Result.error(BaseMessage.服务器内部错误请联系管理员.name());
    }

    /**
     * 保存用户
     * @param userAccount 用户对象
     * @return /
     */
    @PostMapping("/publish")
    public Result publish(UserAccount userAccount){

        try{


            if (StringUtils.isEmpty(userAccount.getSerial())){

                userAccount.setSerial(DataUtil.getComSerial());

                if(userAccountService.save(userAccount)){
                    emailService.userCreationMail(userAccount);
                    return Result.success("新增成功");

                }
                else {
                    return Result.error("新增失败");
                }
            }
            else {

                UserAccount dest = userAccountService.findBySerial(userAccount.getSerial());

                if (dest == null){
                    return Result.error("当前用户信息不存在");
                }

                userAccount.setRealName("张三三");

                return userAccountService.update(userAccount) ? Result.success("修改成功") : Result.error("修改失败");

            }
        }catch (Exception e){
            e.printStackTrace();
        }

        return Result.error(BaseMessage.服务器内部错误请联系管理员.name());
    }

    /**
     * 删除用户
     * @param requestUserAccount  用户唯一编号
     * @return /
     */
    @GetMapping("/remove")
    public Result remove(UserAccount requestUserAccount){

        try{

            UserAccount userAccount = userAccountService.findBySerial(requestUserAccount.getSerial());

            if (userAccount == null){
                return Result.error("当前用户不存在");
            }

            return userAccountService.remove(requestUserAccount.getSerial()) ? Result.success("删除成功") : Result.error("删除失败");

        }catch (Exception e){
            e.printStackTrace();
        }

        return Result.error(BaseMessage.服务器内部错误请联系管理员.name());

    }

    /**
     * 用户登录验证
     * @param requestUserAccount
     * @return /
     */
    @PostMapping("/login")
    public Result login(@RequestBody UserAccount requestUserAccount){

        try{

            //密码先加密，再和数据库里加密后的比对
//            String destPwd = DataUtil.getMd5Password(requestUserAccount.getPassword());

            UserAccount userAccount = userAccountService.findByPassword(requestUserAccount.getAccount(),requestUserAccount.getPassword());

            if (userAccount == null){
                return Result.error("账号密码错误");
            }

            return Result.success("登录成功",userAccount);

        }catch (Exception e){
            e.printStackTrace();
        }

        return Result.error(BaseMessage.服务器内部错误请联系管理员.name());

    }


    /**
     * 调度员分配rfid
     * @param email 邮箱地址
     * @param rfid  设备号
     * @param password  密码
     * @param role  用户角色 （送货员\客户)
     * @return
     */
    @PostMapping("/share/rfid")
    public Result shareRfid(@RequestParam("email") String email,@RequestParam("rfid") String rfid,
                            @RequestParam("password") String password,String role,String serial){

        try{

            UserAccount current = userAccountService.findBySerial(serial);

            if (current == null){
                return Result.error("当前登录人员不存在，请核实后再操作");
            }

            if (!"调度员".equals(current.getRole())){
                return Result.error("当前登录人员无权分配，请通知调度人员");
            }

            if (StringUtils.isEmpty(role)){
                return Result.error("请指定要分配的用户角色");
            }

            UserAccount userAccount = new UserAccount();
            userAccount.setSerial(DataUtil.getComSerial());
            userAccount.setPassword(password);
            userAccount.setEmail(email);
            userAccount.setRfid(rfid);
            userAccount.setRole(role);

            return userAccountService.save(userAccount) ? Result.success("分配成功") : Result.error("分配失败");

        }catch (Exception e){
            e.printStackTrace();
        }

        return Result.error(BaseMessage.服务器内部错误请联系管理员.name());
    }

    /**
     * 调度员创建新的调度员
     * @param password 密码
     * @param email 邮箱
     * @return /
     */
    @PostMapping("/create/scheduler")
    public Result createScheduler(@RequestParam("password") String password,@RequestParam("email") String email){

        try{

            UserAccount userAccount = new UserAccount();
            userAccount.setSerial(DataUtil.getComSerial());
            userAccount.setPassword(password);
            userAccount.setRole("dispatcher");

            return userAccountService.save(userAccount) ? Result.success("创建成功") : Result.error("创建失败");

        }catch (Exception e){
            e.printStackTrace();
        }

        return Result.error(BaseMessage.服务器内部错误请联系管理员.name());
    }
}
