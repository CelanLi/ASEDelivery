package ASE.deliverySpring.controller;

import ASE.deliverySpring.base.BaseController;
import ASE.deliverySpring.base.BaseMessage;
import ASE.deliverySpring.entity.Box;
import ASE.deliverySpring.utils.DataUtil;
import ASE.deliverySpring.utils.Result;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/v1/api/box")
public class BoxController extends BaseController {
    /**
     * box列表查询
     * @return /
     */
    @GetMapping("/find/all")
    public Result findAll(){

        try{

            List<Box> boxs = boxService.findAll();

            return Result.success("查询成功",boxs);

        }catch (Exception e){
            e.printStackTrace();
        }

        return Result.error(BaseMessage.服务器内部错误请联系管理员.name());
    }

    /**
     * 保存box
     * @param box box对象
     * @return
     */
    @PostMapping("/publish")
    public Result publish(Box box){

        try{


            if (StringUtils.isEmpty(box.getSerial())){

                box.setSerial(DataUtil.getComSerial());

                return boxService.save(box) ? Result.success("新增成功") : Result.error("新增失败");


            }else {

                Box dest = boxService.findBySerial(box.getSerial());

                if (dest == null){
                    return Result.error("当前用户信息不存在");
                }


                return boxService.update(box) ? Result.success("修改成功") : Result.error("修改失败");

            }
        }catch (Exception e){
            e.printStackTrace();
        }

        return Result.error(BaseMessage.服务器内部错误请联系管理员.name());
    }

    /**
     * 删除box
     * @param requestBox box唯一编号
     * @return
     */
    @GetMapping("/remove")
    public Result remove(@RequestBody Box requestBox){

        try{

            Box box = boxService.findBySerial(requestBox.getSerial());

            if (box == null){
                return Result.error("当前箱子不存在");
            }

            return boxService.remove(requestBox.getSerial()) ? Result.success("删除成功") : Result.error("删除失败");

        }catch (Exception e){
            e.printStackTrace();
        }

        return Result.error(BaseMessage.服务器内部错误请联系管理员.name());

    }
}
